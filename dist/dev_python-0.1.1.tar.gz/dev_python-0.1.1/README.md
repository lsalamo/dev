---
markmap:
  maxWidth: 300
  colorFreezeLevel: 3
  initialExpandLevel: 5
---

# dev

## <img src='https://i.imgur.com/5WuXRVs.png' style='height:40px;width:auto'> [Python](dev/python/index.md)

## <img src='https://i.imgur.com/c0S3aFz.png' style='height:40px;width:auto'> [JetBrains](dev/jetbrains/index.md)

## <img src='https://i.imgur.com/YeX1O1Q.png' style='height:40px;width:auto'> [Microsoft](dev/meta/index.md)

## <img src='https://i.imgur.com/VbuMhsl.png' style='height:40px;width:auto'> [Anaconda](dev/anaconda/index.md)

## <img src='https://i.imgur.com/nySomdb.png' style='height:40px;width:auto'> [Git](dev/git/index.md)